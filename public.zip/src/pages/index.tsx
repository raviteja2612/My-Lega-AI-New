"use client"

import { useEffect } from "react"
import Head from "next/head"
import { useRouter } from "next/router"
import dynamic from "next/dynamic"
import type { GetStaticProps } from "next"
import { User, Gavel } from "lucide-react"
import { useTranslation } from "../hooks/useTranslation"

// Dynamically import components for better performance
const Navigation = dynamic(() => import("../components/shared/Navigation"), { ssr: true })
const Hero = dynamic(() => import("../components/shared/Hero"), { ssr: true })
const OptionCard = dynamic(() => import("../components/shared/OptionCard"), { ssr: true })
const SectionHeader = dynamic(() => import("../components/shared/SectionHeader"), { ssr: true })
const FeatureCard = dynamic(() => import("../components/shared/FeatureCard"), {
  ssr: false,
  loading: () => <FeatureCardSkeleton />,
})
const CTASection = dynamic(() => import("../components/shared/CTASection"), {
  ssr: false,
  loading: () => <div className="h-[250px] bg-gray-200 animate-pulse"></div>,
})
const Footer = dynamic(() => import("../components/shared/Footer"), { ssr: true })

// Lazy-loaded icons for feature cards
const FeatureIcons = {
  FileText: dynamic(() => import("lucide-react").then((mod) => mod.FileText)),
  BarChart: dynamic(() => import("lucide-react").then((mod) => mod.BarChart)),
  Users: dynamic(() => import("lucide-react").then((mod) => mod.Users)),
  UserCheck: dynamic(() => import("lucide-react").then((mod) => mod.UserCheck)),
  ClipboardList: dynamic(() => import("lucide-react").then((mod) => mod.ClipboardList)),
  ShieldCheck: dynamic(() => import("lucide-react").then((mod) => mod.ShieldCheck)),
  LayoutDashboard: dynamic(() => import("lucide-react").then((mod) => mod.LayoutDashboard)),
  BookOpen: dynamic(() => import("lucide-react").then((mod) => mod.BookOpen)),
  Network: dynamic(() => import("lucide-react").then((mod) => mod.Network)),
  Workflow: dynamic(() => import("lucide-react").then((mod) => mod.Workflow)),
}

// Skeleton loader for feature cards
function FeatureCardSkeleton() {
  return (
    <div className="bg-white rounded-lg overflow-hidden border-t-4 border-blue-500 shadow-sm p-6 animate-pulse">
      <div className="w-12 h-12 bg-blue-100 rounded-full mx-auto mb-4"></div>
      <div className="h-8 bg-gray-200 rounded mb-3 mx-auto w-3/4"></div>
      <div className="h-20 bg-gray-200 rounded mx-auto"></div>
    </div>
  )
}

export default function Home() {
  const router = useRouter()
  const { t } = useTranslation()

  // Preload critical fonts
  useEffect(() => {
    const link = document.createElement("link")
    link.rel = "preload"
    link.href = "https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap"
    link.as = "style"
    document.head.appendChild(link)
  }, [])

  // Handle routing for consumer and professional buttons
  const handleConsumerClick = () => {
    localStorage.setItem("tempRole", "consumer")
    router.push("/signin?role=consumer")
  }

  const handleProfessionalClick = () => {
    localStorage.setItem("tempRole", "professional")
    router.push("/signin?role=professional")
  }

  return (
    <div className="min-h-screen font-['Inter',sans-serif]">
      <Head>
        <title>{t.meta.title}</title>
        <meta name="description" content={t.meta.description} />
        <link rel="icon" href="/favicon.ico" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap"
          rel="stylesheet"
        />
      </Head>

      <Navigation />
      <Hero />

      {/* Two-column section */}
      <div className="bg-blue-700 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-8">
            <OptionCard
              title={t.options.individual.title}
              description={t.options.individual.description}
              buttonText={t.options.individual.button}
              features={t.options.individual.features}
              icon={<User className="h-6 w-6 text-white" />}
              onClick={handleConsumerClick}
            />
            <OptionCard
              title={t.options.professional.title}
              description={t.options.professional.description}
              buttonText={t.options.professional.button}
              features={t.options.professional.features}
              icon={<Gavel className="h-6 w-6 text-white" />}
              onClick={handleProfessionalClick}
              delay={0.1}
            />
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeader title={t.features.title} subtitle={t.features.subtitle} />

          {/* For Individuals */}
          <div className="mb-16">
            <SectionHeader title={t.features.individuals.title} />
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {t.features.individuals.cards.map((card, index) => (
                <FeatureCard
                  key={index}
                  title={card.title}
                  description={card.description}
                  icon={<FeatureIcons.FileText className="h-6 w-6 text-blue-600" />}
                />
              ))}
            </div>
          </div>

          {/* For Legal Professionals */}
          <div>
            <SectionHeader title={t.features.professionals.title} />
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {t.features.professionals.cards.map((card, index) => (
                <FeatureCard
                  key={index}
                  title={card.title}
                  description={card.description}
                  icon={<FeatureIcons.LayoutDashboard className="h-6 w-6 text-blue-600" />}
                />
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <CTASection
        title={t.cta.title}
        subtitle={t.cta.subtitle}
        buttonText={t.cta.button}
        onClick={() => router.push("/signin?role=professional")}
      />

      <Footer />
    </div>
  )
}

// Use Static Site Generation for better performance
export const getStaticProps: GetStaticProps = async () => {
  return {
    props: {},
    // Revalidate every 24 hours
    revalidate: 86400,
  }
}
