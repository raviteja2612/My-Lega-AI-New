"use client"

import { motion } from "framer-motion"
import { Users, Award, Shield, Globe, CheckCircle, Clock, Zap } from "lucide-react"
import Layout from "../components/Layout"
import PageHeader from "../components/PageHeader"

export default function About() {
  return (
    <Layout title="About" description="Learn about My Legal AI and our mission to make legal help accessible">
      <PageHeader
        title="About My Legal AI"
        subtitle="Our mission is to make quality legal help accessible to everyone"
      />

      {/* Mission Section */}
      <div className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <h2 className="text-3xl font-bold text-gray-900 mb-6">Our Mission</h2>
              <p className="text-lg text-gray-600 mb-6">
                At My Legal AI, we believe that everyone deserves access to quality legal help, regardless of their
                background or resources. Our mission is to democratize legal assistance by leveraging artificial
                intelligence to provide affordable, accessible, and accurate legal guidance to individuals and enhanced
                tools for legal professionals.
              </p>
              <p className="text-lg text-gray-600 mb-8">
                We're bridging the justice gap by combining cutting-edge AI technology with legal expertise to create a
                platform that empowers users to understand their legal rights, explore their options, and connect with
                the right legal resources when needed.
              </p>
              <div className="grid grid-cols-2 gap-6">
                <div className="flex items-start">
                  <div className="bg-blue-100 p-2 rounded-full mr-3 mt-1">
                    <Users className="h-5 w-5 text-blue-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">For Everyone</h4>
                    <p className="text-gray-600">Making legal help accessible to all</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="bg-blue-100 p-2 rounded-full mr-3 mt-1">
                    <Award className="h-5 w-5 text-blue-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">Quality First</h4>
                    <p className="text-gray-600">Committed to accuracy and excellence</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="bg-blue-100 p-2 rounded-full mr-3 mt-1">
                    <Shield className="h-5 w-5 text-blue-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">Secure & Private</h4>
                    <p className="text-gray-600">Your data is always protected</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="bg-blue-100 p-2 rounded-full mr-3 mt-1">
                    <Globe className="h-5 w-5 text-blue-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">Global Reach</h4>
                    <p className="text-gray-600">Serving clients worldwide</p>
                  </div>
                </div>
              </div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="relative"
            >
              <div className="absolute -top-6 -left-6 w-24 h-24 bg-blue-100 rounded-lg z-0"></div>
              <div className="absolute -bottom-6 -right-6 w-24 h-24 bg-blue-100 rounded-lg z-0"></div>
              <img
                src="/diverse-portrait.png"
                alt="Diverse team of legal professionals"
                className="rounded-lg shadow-xl relative z-10"
              />
            </motion.div>
          </div>
        </div>
      </div>

      {/* Our Story Section */}
      <div className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-gray-900">Our Story</h2>
            <p className="mt-4 text-xl text-gray-600 max-w-3xl mx-auto">
              From a simple idea to a comprehensive legal AI platform
            </p>
          </motion.div>

          <div className="max-w-3xl mx-auto">
            <div className="space-y-12">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
                viewport={{ once: true }}
                className="relative pl-10 border-l-2 border-blue-200"
              >
                <div className="absolute left-[-9px] top-0 w-4 h-4 rounded-full bg-blue-600"></div>
                <div>
                  <h3 className="text-xl font-bold text-gray-900">2024: The Beginning</h3>
                  <p className="mt-2 text-gray-600">
                    Founded by a team of legal professionals and AI experts who recognized the growing justice gap and
                    the potential for technology to help bridge it. Our initial prototype focused on answering basic
                    legal questions.
                  </p>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                viewport={{ once: true }}
                className="relative pl-10 border-l-2 border-blue-200"
              >
                <div className="absolute left-[-9px] top-0 w-4 h-4 rounded-full bg-blue-600"></div>
                <div>
                  <h3 className="text-xl font-bold text-gray-900">2025: Expanding Capabilities</h3>
                  <p className="mt-2 text-gray-600">
                    Developed our core AI models specifically trained on legal data. Launched our first beta platform
                    with case analysis and document generation capabilities for a limited set of legal issues.
                  </p>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.4 }}
                viewport={{ once: true }}
                className="relative pl-10 border-l-2 border-blue-200"
              >
                <div className="absolute left-[-9px] top-0 w-4 h-4 rounded-full bg-blue-600"></div>
                <div>
                  <h3 className="text-xl font-bold text-gray-900">2025: Professional Tools</h3>
                  <p className="mt-2 text-gray-600">
                    Expanded our platform to include specialized tools for legal professionals. Introduced our attorney
                    matching service to connect individuals with the right legal help when needed.
                  </p>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.6 }}
                viewport={{ once: true }}
                className="relative pl-10"
              >
                <div className="absolute left-[-9px] top-0 w-4 h-4 rounded-full bg-blue-600"></div>
                <div>
                  <h3 className="text-xl font-bold text-gray-900">2026: Today and Beyond</h3>
                  <p className="mt-2 text-gray-600">
                    Now serving thousands of users across multiple legal domains. Continuously improving our AI models
                    and expanding our capabilities to cover more legal areas and jurisdictions.
                  </p>
                </div>
              </motion.div>
            </div>
          </div>
        </div>
      </div>

      {/* Why Choose Us Section */}
      <div className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-gray-900">Why Choose My Legal AI</h2>
            <p className="mt-4 text-xl text-gray-600 max-w-3xl mx-auto">
              What sets our platform apart from traditional legal services
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
              className="bg-gray-50 rounded-lg p-8"
            >
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-6">
                <CheckCircle className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Accuracy & Reliability</h3>
              <p className="text-gray-600">
                Our AI models are trained on millions of legal documents and continuously reviewed by legal experts to
                ensure accuracy and reliability.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              viewport={{ once: true }}
              className="bg-gray-50 rounded-lg p-8"
            >
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-6">
                <Clock className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">24/7 Availability</h3>
              <p className="text-gray-600">
                Get legal guidance whenever you need it, without waiting for appointments or office hours. Our platform
                is available around the clock.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              viewport={{ once: true }}
              className="bg-gray-50 rounded-lg p-8"
            >
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-6">
                <Zap className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Cost-Effective</h3>
              <p className="text-gray-600">
                Our subscription-based model provides affordable access to legal guidance at a fraction of the cost of
                traditional legal services.
              </p>
            </motion.div>
          </div>
        </div>
      </div>

      {/* Team Section */}
      <div className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-gray-900">Our Leadership Team</h2>
            <p className="mt-4 text-xl text-gray-600 max-w-3xl mx-auto">Meet the experts behind My Legal AI</p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
              className="text-center"
            >
              <div className="w-48 h-48 rounded-full bg-gray-300 mx-auto mb-6 overflow-hidden">
                <img src="/placeholder.svg?key=67fxp" alt="Sarah Johnson, CEO" className="w-full h-full object-cover" />
              </div>
              <h3 className="text-xl font-bold text-gray-900">Sarah Johnson</h3>
              <p className="text-blue-600 mb-4">CEO & Co-Founder</p>
              <p className="text-gray-600">
                Former litigation attorney with 15+ years of experience. Passionate about making legal help accessible
                to everyone.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              viewport={{ once: true }}
              className="text-center"
            >
              <div className="w-48 h-48 rounded-full bg-gray-300 mx-auto mb-6 overflow-hidden">
                <img src="/placeholder.svg?key=jjv4u" alt="Michael Chen, CTO" className="w-full h-full object-cover" />
              </div>
              <h3 className="text-xl font-bold text-gray-900">Michael Chen</h3>
              <p className="text-blue-600 mb-4">CTO & Co-Founder</p>
              <p className="text-gray-600">
                AI researcher with a background in NLP and machine learning. Previously led AI teams at major tech
                companies.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              viewport={{ once: true }}
              className="text-center"
            >
              <div className="w-48 h-48 rounded-full bg-gray-300 mx-auto mb-6 overflow-hidden">
                <img
                  src="/placeholder.svg?key=5xwex"
                  alt="Dr. Amara Patel, Legal Director"
                  className="w-full h-full object-cover"
                />
              </div>
              <h3 className="text-xl font-bold text-gray-900">Dr. Amara Patel</h3>
              <p className="text-blue-600 mb-4">Legal Director</p>
              <p className="text-gray-600">
                Former law professor specializing in legal technology and access to justice. Oversees legal accuracy of
                our platform.
              </p>
            </motion.div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-blue-700 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-3xl font-bold text-white mb-6"
          >
            Join us in our mission to democratize legal help
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.6 }}
            viewport={{ once: true }}
            className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto"
          >
            Whether you're seeking legal assistance or a legal professional looking to enhance your practice, we're here
            to help
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.6 }}
            viewport={{ once: true }}
            className="flex flex-col sm:flex-row justify-center gap-4"
          >
            <motion.a
              href="/src/pages/signin?role=consumer"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="bg-white text-blue-700 px-8 py-3 rounded-md hover:bg-gray-100 transition-colors duration-200 font-semibold text-lg"
            >
              Get Started
            </motion.a>
            <motion.a
              href="/contact"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="bg-blue-600 text-white border border-blue-400 px-8 py-3 rounded-md hover:bg-blue-800 transition-colors duration-200 font-semibold text-lg"
            >
              Contact Us
            </motion.a>
          </motion.div>
        </div>
      </div>
    </Layout>
  )
}
