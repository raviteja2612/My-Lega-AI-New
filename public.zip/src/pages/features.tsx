"use client"

import { motion } from "framer-motion"
import {
  FileText,
  BarChart,
  Users,
  UserCheck,
  ClipboardList,
  ShieldCheck,
  LayoutDashboard,
  BookOpen,
  FileCheck,
  Network,
  Workflow,
  Bot,
  Scale,
  FileSearch,
  Gavel,
  Brain,
  Lock,
  Zap,
} from "lucide-react"
import Layout from "../components/Layout"
import PageHeader from "../components/PageHeader"

// Animation variants
const fadeIn = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, ease: "easeOut" },
  },
}

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
}

const cardVariant = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5, ease: "easeOut" },
  },
}

export default function Features() {
  return (
    <Layout title="Features" description="Explore the powerful features of My Legal AI platform">
      <PageHeader
        title="Powerful Legal AI Features"
        subtitle="Discover how our AI-powered platform can transform your legal experience"
        backgroundImage="/lady-justice-dark-scales.png"
      />

      {/* Core Features Section */}
      <div className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={fadeIn}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-gray-900">Core Platform Features</h2>
            <p className="mt-4 text-xl text-gray-600">
              Our platform combines cutting-edge AI with legal expertise to provide comprehensive solutions
            </p>
          </motion.div>

          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={staggerContainer}
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
          >
            {/* AI Legal Assistant */}
            <motion.div
              variants={cardVariant}
              whileHover={{ y: -8 }}
              className="bg-white rounded-lg overflow-hidden border border-gray-200 transition-all duration-300 hover:shadow-xl"
            >
              <div className="p-8">
                <div className="w-14 h-14 bg-blue-100 rounded-full flex items-center justify-center mb-6">
                  <Bot className="h-7 w-7 text-blue-600" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">AI Legal Assistant</h3>
                <p className="text-gray-600 mb-6">
                  Our conversational AI assistant answers legal questions, explains complex legal concepts, and guides
                  you through legal processes in plain language.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <div className="text-blue-600 mr-3 mt-1 flex-shrink-0">
                      <svg className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path
                          fillRule="evenodd"
                          d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                          clipRule="evenodd"
                        />
                      </svg>
                    </div>
                    <p className="text-gray-700">24/7 legal guidance</p>
                  </li>
                  <li className="flex items-start">
                    <div className="text-blue-600 mr-3 mt-1 flex-shrink-0">
                      <svg className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path
                          fillRule="evenodd"
                          d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                          clipRule="evenodd"
                        />
                      </svg>
                    </div>
                    <p className="text-gray-700">Plain language explanations</p>
                  </li>
                  <li className="flex items-start">
                    <div className="text-blue-600 mr-3 mt-1 flex-shrink-0">
                      <svg className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path
                          fillRule="evenodd"
                          d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                          clipRule="evenodd"
                        />
                      </svg>
                    </div>
                    <p className="text-gray-700">Contextual recommendations</p>
                  </li>
                </ul>
              </div>
            </motion.div>

            {/* Case Analysis */}
            <motion.div
              variants={cardVariant}
              whileHover={{ y: -8 }}
              className="bg-white rounded-lg overflow-hidden border border-gray-200 transition-all duration-300 hover:shadow-xl"
            >
              <div className="p-8">
                <div className="w-14 h-14 bg-blue-100 rounded-full flex items-center justify-center mb-6">
                  <FileSearch className="h-7 w-7 text-blue-600" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">Case Analysis</h3>
                <p className="text-gray-600 mb-6">
                  Our AI analyzes your legal situation, identifies potential claims, defenses, and legal issues,
                  providing a comprehensive assessment.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <div className="text-blue-600 mr-3 mt-1 flex-shrink-0">
                      <svg className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path
                          fillRule="evenodd"
                          d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                          clipRule="evenodd"
                        />
                      </svg>
                    </div>
                    <p className="text-gray-700">Issue identification</p>
                  </li>
                  <li className="flex items-start">
                    <div className="text-blue-600 mr-3 mt-1 flex-shrink-0">
                      <svg className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path
                          fillRule="evenodd"
                          d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                          clipRule="evenodd"
                        />
                      </svg>
                    </div>
                    <p className="text-gray-700">Strength/weakness assessment</p>
                  </li>
                  <li className="flex items-start">
                    <div className="text-blue-600 mr-3 mt-1 flex-shrink-0">
                      <svg className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path
                          fillRule="evenodd"
                          d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                          clipRule="evenodd"
                        />
                      </svg>
                    </div>
                    <p className="text-gray-700">Legal strategy recommendations</p>
                  </li>
                </ul>
              </div>
            </motion.div>

            {/* Outcome Prediction */}
            <motion.div
              variants={cardVariant}
              whileHover={{ y: -8 }}
              className="bg-white rounded-lg overflow-hidden border border-gray-200 transition-all duration-300 hover:shadow-xl"
            >
              <div className="p-8">
                <div className="w-14 h-14 bg-blue-100 rounded-full flex items-center justify-center mb-6">
                  <BarChart className="h-7 w-7 text-blue-600" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">Outcome Prediction</h3>
                <p className="text-gray-600 mb-6">
                  Using machine learning trained on thousands of similar cases, our platform predicts potential outcomes
                  and success probabilities.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <div className="text-blue-600 mr-3 mt-1 flex-shrink-0">
                      <svg className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path
                          fillRule="evenodd"
                          d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                          clipRule="evenodd"
                        />
                      </svg>
                    </div>
                    <p className="text-gray-700">Win/loss probability</p>
                  </li>
                  <li className="flex items-start">
                    <div className="text-blue-600 mr-3 mt-1 flex-shrink-0">
                      <svg className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path
                          fillRule="evenodd"
                          d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                          clipRule="evenodd"
                        />
                      </svg>
                    </div>
                    <p className="text-gray-700">Settlement estimates</p>
                  </li>
                  <li className="flex items-start">
                    <div className="text-blue-600 mr-3 mt-1 flex-shrink-0">
                      <svg className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path
                          fillRule="evenodd"
                          d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                          clipRule="evenodd"
                        />
                      </svg>
                    </div>
                    <p className="text-gray-700">Timeline projections</p>
                  </li>
                </ul>
              </div>
            </motion.div>

            {/* Document Automation */}
            <motion.div
              variants={cardVariant}
              whileHover={{ y: -8 }}
              className="bg-white rounded-lg overflow-hidden border border-gray-200 transition-all duration-300 hover:shadow-xl"
            >
              <div className="p-8">
                <div className="w-14 h-14 bg-blue-100 rounded-full flex items-center justify-center mb-6">
                  <FileCheck className="h-7 w-7 text-blue-600" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">Document Automation</h3>
                <p className="text-gray-600 mb-6">
                  Generate professional legal documents tailored to your specific situation with our AI-powered document
                  automation system.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <div className="text-blue-600 mr-3 mt-1 flex-shrink-0">
                      <svg className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path
                          fillRule="evenodd"
                          d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                          clipRule="evenodd"
                        />
                      </svg>
                    </div>
                    <p className="text-gray-700">Smart templates</p>
                  </li>
                  <li className="flex items-start">
                    <div className="text-blue-600 mr-3 mt-1 flex-shrink-0">
                      <svg className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path
                          fillRule="evenodd"
                          d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                          clipRule="evenodd"
                        />
                      </svg>
                    </div>
                    <p className="text-gray-700">Jurisdiction-specific forms</p>
                  </li>
                  <li className="flex items-start">
                    <div className="text-blue-600 mr-3 mt-1 flex-shrink-0">
                      <svg className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path
                          fillRule="evenodd"
                          d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                          clipRule="evenodd"
                        />
                      </svg>
                    </div>
                    <p className="text-gray-700">Electronic signatures</p>
                  </li>
                </ul>
              </div>
            </motion.div>

            {/* Attorney Matching */}
            <motion.div
              variants={cardVariant}
              whileHover={{ y: -8 }}
              className="bg-white rounded-lg overflow-hidden border border-gray-200 transition-all duration-300 hover:shadow-xl"
            >
              <div className="p-8">
                <div className="w-14 h-14 bg-blue-100 rounded-full flex items-center justify-center mb-6">
                  <Users className="h-7 w-7 text-blue-600" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">Attorney Matching</h3>
                <p className="text-gray-600 mb-6">
                  Our platform connects you with qualified attorneys specialized in your specific legal issue, based on
                  expertise, location, and budget.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <div className="text-blue-600 mr-3 mt-1 flex-shrink-0">
                      <svg className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path
                          fillRule="evenodd"
                          d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                          clipRule="evenodd"
                        />
                      </svg>
                    </div>
                    <p className="text-gray-700">Expertise-based matching</p>
                  </li>
                  <li className="flex items-start">
                    <div className="text-blue-600 mr-3 mt-1 flex-shrink-0">
                      <svg className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path
                          fillRule="evenodd"
                          d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                          clipRule="evenodd"
                        />
                      </svg>
                    </div>
                    <p className="text-gray-700">Verified attorney profiles</p>
                  </li>
                  <li className="flex items-start">
                    <div className="text-blue-600 mr-3 mt-1 flex-shrink-0">
                      <svg className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path
                          fillRule="evenodd"
                          d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                          clipRule="evenodd"
                        />
                      </svg>
                    </div>
                    <p className="text-gray-700">Secure communication</p>
                  </li>
                </ul>
              </div>
            </motion.div>

            {/* Legal Research */}
            <motion.div
              variants={cardVariant}
              whileHover={{ y: -8 }}
              className="bg-white rounded-lg overflow-hidden border border-gray-200 transition-all duration-300 hover:shadow-xl"
            >
              <div className="p-8">
                <div className="w-14 h-14 bg-blue-100 rounded-full flex items-center justify-center mb-6">
                  <BookOpen className="h-7 w-7 text-blue-600" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">Legal Research</h3>
                <p className="text-gray-600 mb-6">
                  Our AI-powered research tools analyze millions of cases, statutes, and legal documents to provide
                  relevant legal information.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <div className="text-blue-600 mr-3 mt-1 flex-shrink-0">
                      <svg className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path
                          fillRule="evenodd"
                          d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                          clipRule="evenodd"
                        />
                      </svg>
                    </div>
                    <p className="text-gray-700">Case law analysis</p>
                  </li>
                  <li className="flex items-start">
                    <div className="text-blue-600 mr-3 mt-1 flex-shrink-0">
                      <svg className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path
                          fillRule="evenodd"
                          d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                          clipRule="evenodd"
                        />
                      </svg>
                    </div>
                    <p className="text-gray-700">Statute interpretation</p>
                  </li>
                  <li className="flex items-start">
                    <div className="text-blue-600 mr-3 mt-1 flex-shrink-0">
                      <svg className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path
                          fillRule="evenodd"
                          d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                          clipRule="evenodd"
                        />
                      </svg>
                    </div>
                    <p className="text-gray-700">Precedent finding</p>
                  </li>
                </ul>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>

      {/* For Individuals Section */}
      <div className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={fadeIn}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-gray-900">For Individuals</h2>
            <p className="mt-4 text-xl text-gray-600">
              Specialized features designed to help individuals navigate their legal challenges
            </p>
          </motion.div>

          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={staggerContainer}
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {/* AI Case Review */}
            <motion.div
              variants={cardVariant}
              whileHover={{ y: -8 }}
              className="bg-white rounded-lg overflow-hidden border-t-4 border-blue-500 transition-all duration-300 hover:border-blue-600 hover:bg-blue-50 shadow-[0_4px_14px_0_rgba(59,130,246,0.2)] hover:shadow-[0_6px_20px_rgba(59,130,246,0.3)]"
            >
              <div className="p-6">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4 mx-auto">
                  <FileText className="h-6 w-6 text-blue-600" />
                </div>
                <h4 className="text-2xl font-semibold text-center mb-3 text-blue-700">AI Case Review</h4>
                <p className="text-gray-600 text-center text-lg">
                  Get instant analysis of your legal situation with our AI system. Understand key issues and potential
                  violations in plain English.
                </p>
              </div>
            </motion.div>

            {/* Outcome Prediction */}
            <motion.div
              variants={cardVariant}
              whileHover={{ y: -8 }}
              className="bg-white rounded-lg overflow-hidden border-t-4 border-blue-500 transition-all duration-300 hover:border-blue-600 hover:bg-blue-50 shadow-[0_4px_14px_0_rgba(59,130,246,0.2)] hover:shadow-[0_6px_20px_rgba(59,130,246,0.3)]"
            >
              <div className="p-6">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4 mx-auto">
                  <BarChart className="h-6 w-6 text-blue-600" />
                </div>
                <h4 className="text-2xl font-semibold text-center mb-3 text-blue-700">Outcome Prediction</h4>
                <p className="text-gray-600 text-center text-lg">
                  Understand your chances of success with our predictive analysis, including win/settle probability
                  estimates based on similar cases.
                </p>
              </div>
            </motion.div>

            {/* Attorney Matching */}
            <motion.div
              variants={cardVariant}
              whileHover={{ y: -8 }}
              className="bg-white rounded-lg overflow-hidden border-t-4 border-blue-500 transition-all duration-300 hover:border-blue-600 hover:bg-blue-50 shadow-[0_4px_14px_0_rgba(59,130,246,0.2)] hover:shadow-[0_6px_20px_rgba(59,130,246,0.3)]"
            >
              <div className="p-6">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4 mx-auto">
                  <Users className="h-6 w-6 text-blue-600" />
                </div>
                <h4 className="text-2xl font-semibold text-center mb-3 text-blue-700">Attorney Matching</h4>
                <p className="text-gray-600 text-center text-lg">
                  Get matched with the right legal professional based on your case type, budget, and location.
                </p>
              </div>
            </motion.div>

            {/* Self-Rep Guidance */}
            <motion.div
              variants={cardVariant}
              whileHover={{ y: -8 }}
              className="bg-white rounded-lg overflow-hidden border-t-4 border-blue-500 transition-all duration-300 hover:border-blue-600 hover:bg-blue-50 shadow-[0_4px_14px_0_rgba(59,130,246,0.2)] hover:shadow-[0_6px_20px_rgba(59,130,246,0.3)]"
            >
              <div className="p-6">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4 mx-auto">
                  <UserCheck className="h-6 w-6 text-blue-600" />
                </div>
                <h4 className="text-2xl font-semibold text-center mb-3 text-blue-700">Self-Rep Guidance</h4>
                <p className="text-gray-600 text-center text-lg">
                  Receive personalized advice on whether to self-represent or hire counsel, with step-by-step guidance
                  for small claims cases.
                </p>
              </div>
            </motion.div>

            {/* Evidence Management */}
            <motion.div
              variants={cardVariant}
              whileHover={{ y: -8 }}
              className="bg-white rounded-lg overflow-hidden border-t-4 border-blue-500 transition-all duration-300 hover:border-blue-600 hover:bg-blue-50 shadow-[0_4px_14px_0_rgba(59,130,246,0.2)] hover:shadow-[0_6px_20px_rgba(59,130,246,0.3)]"
            >
              <div className="p-6">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4 mx-auto">
                  <ClipboardList className="h-6 w-6 text-blue-600" />
                </div>
                <h4 className="text-2xl font-semibold text-center mb-3 text-blue-700">Evidence Management</h4>
                <p className="text-gray-600 text-center text-lg">
                  Get customized evidence checklists, document review, and strategic recommendations for strengthening
                  your case.
                </p>
              </div>
            </motion.div>

            {/* Defense Strategies */}
            <motion.div
              variants={cardVariant}
              whileHover={{ y: -8 }}
              className="bg-white rounded-lg overflow-hidden border-t-4 border-blue-500 transition-all duration-300 hover:border-blue-600 hover:bg-blue-50 shadow-[0_4px_14px_0_rgba(59,130,246,0.2)] hover:shadow-[0_6px_20px_rgba(59,130,246,0.3)]"
            >
              <div className="p-6">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4 mx-auto">
                  <ShieldCheck className="h-6 w-6 text-blue-600" />
                </div>
                <h4 className="text-2xl font-semibold text-center mb-3 text-blue-700">Defense Strategies</h4>
                <p className="text-gray-600 text-center text-lg">
                  Access AI-generated defense recommendations and legal strategies tailored to your specific situation.
                </p>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>

      {/* For Legal Professionals Section */}
      <div className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={fadeIn}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-gray-900">For Legal Professionals</h2>
            <p className="mt-4 text-xl text-gray-600">
              Advanced tools to enhance your legal practice and serve clients more effectively
            </p>
          </motion.div>

          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={staggerContainer}
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {/* Smart Practice Dashboard */}
            <motion.div
              variants={cardVariant}
              whileHover={{ y: -8 }}
              className="bg-white rounded-lg overflow-hidden border-t-4 border-blue-500 transition-all duration-300 hover:border-blue-600 hover:bg-blue-50 shadow-[0_4px_14px_0_rgba(59,130,246,0.2)] hover:shadow-[0_6px_20px_rgba(59,130,246,0.3)]"
            >
              <div className="p-6">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4 mx-auto">
                  <LayoutDashboard className="h-6 w-6 text-blue-600" />
                </div>
                <h4 className="text-2xl font-semibold text-center mb-3 text-blue-700">Smart Practice Dashboard</h4>
                <p className="text-gray-600 text-center text-lg">
                  Centralized view of your cases, client intakes, and practice metrics with intelligent insights and
                  quick actions.
                </p>
              </div>
            </motion.div>

            {/* AI Case Law Research */}
            <motion.div
              variants={cardVariant}
              whileHover={{ y: -8 }}
              className="bg-white rounded-lg overflow-hidden border-t-4 border-blue-500 transition-all duration-300 hover:border-blue-600 hover:bg-blue-50 shadow-[0_4px_14px_0_rgba(59,130,246,0.2)] hover:shadow-[0_6px_20px_rgba(59,130,246,0.3)]"
            >
              <div className="p-6">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4 mx-auto">
                  <BookOpen className="h-6 w-6 text-blue-600" />
                </div>
                <h4 className="text-2xl font-semibold text-center mb-3 text-blue-700">AI Case Law Research</h4>
                <p className="text-gray-600 text-center text-lg">
                  Advanced legal research with AI-powered case analysis, precedent finding, and automated brief
                  generation.
                </p>
              </div>
            </motion.div>

            {/* Document Automation */}
            <motion.div
              variants={cardVariant}
              whileHover={{ y: -8 }}
              className="bg-white rounded-lg overflow-hidden border-t-4 border-blue-500 transition-all duration-300 hover:border-blue-600 hover:bg-blue-50 shadow-[0_4px_14px_0_rgba(59,130,246,0.2)] hover:shadow-[0_6px_20px_rgba(59,130,246,0.3)]"
            >
              <div className="p-6">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4 mx-auto">
                  <FileCheck className="h-6 w-6 text-blue-600" />
                </div>
                <h4 className="text-2xl font-semibold text-center mb-3 text-blue-700">Document Automation</h4>
                <p className="text-gray-600 text-center text-lg">
                  Generate professional legal documents with smart templates, automated filling, and customizable
                  workflows.
                </p>
              </div>
            </motion.div>

            {/* Client Intake & Management */}
            <motion.div
              variants={cardVariant}
              whileHover={{ y: -8 }}
              className="bg-white rounded-lg overflow-hidden border-t-4 border-blue-500 transition-all duration-300 hover:border-blue-600 hover:bg-blue-50 shadow-[0_4px_14px_0_rgba(59,130,246,0.2)] hover:shadow-[0_6px_20px_rgba(59,130,246,0.3)]"
            >
              <div className="p-6">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4 mx-auto">
                  <Users className="h-6 w-6 text-blue-600" />
                </div>
                <h4 className="text-2xl font-semibold text-center mb-3 text-blue-700">Client Intake & Management</h4>
                <p className="text-gray-600 text-center text-lg">
                  Streamline client onboarding with AI-powered intake forms, risk assessment, and case evaluation tools.
                </p>
              </div>
            </motion.div>

            {/* Practice Integrations */}
            <motion.div
              variants={cardVariant}
              whileHover={{ y: -8 }}
              className="bg-white rounded-lg overflow-hidden border-t-4 border-blue-500 transition-all duration-300 hover:border-blue-600 hover:bg-blue-50 shadow-[0_4px_14px_0_rgba(59,130,246,0.2)] hover:shadow-[0_6px_20px_rgba(59,130,246,0.3)]"
            >
              <div className="p-6">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4 mx-auto">
                  <Network className="h-6 w-6 text-blue-600" />
                </div>
                <h4 className="text-2xl font-semibold text-center mb-3 text-blue-700">Practice Integrations</h4>
                <p className="text-gray-600 text-center text-lg">
                  Seamlessly connect with popular legal software like Clio, Outlook, and document management systems.
                </p>
              </div>
            </motion.div>

            {/* Workflow Automation */}
            <motion.div
              variants={cardVariant}
              whileHover={{ y: -8 }}
              className="bg-white rounded-lg overflow-hidden border-t-4 border-blue-500 transition-all duration-300 hover:border-blue-600 hover:bg-blue-50 shadow-[0_4px_14px_0_rgba(59,130,246,0.2)] hover:shadow-[0_6px_20px_rgba(59,130,246,0.3)]"
            >
              <div className="p-6">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4 mx-auto">
                  <Workflow className="h-6 w-6 text-blue-600" />
                </div>
                <h4 className="text-2xl font-semibold text-center mb-3 text-blue-700">Workflow Automation</h4>
                <p className="text-gray-600 text-center text-lg">
                  Automate routine tasks, set up custom workflows, and track case progress with intelligent pipelines.
                </p>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>

      {/* Technology Section */}
      <div className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={fadeIn}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-gray-900">Our Technology</h2>
            <p className="mt-4 text-xl text-gray-600">Powered by cutting-edge AI and legal expertise</p>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <h3 className="text-3xl font-bold text-gray-900 mb-6">Advanced AI Models</h3>
              <p className="text-lg text-gray-600 mb-6">
                Our platform leverages state-of-the-art large language models and specialized legal AI to provide
                accurate, context-aware legal analysis and guidance.
              </p>
              <ul className="space-y-4">
                <li className="flex items-start">
                  <div className="bg-blue-100 p-2 rounded-full mr-4 mt-1">
                    <Brain className="h-5 w-5 text-blue-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">Legal Language Understanding</h4>
                    <p className="text-gray-600">
                      Trained on millions of legal documents to understand complex legal terminology and concepts
                    </p>
                  </div>
                </li>
                <li className="flex items-start">
                  <div className="bg-blue-100 p-2 rounded-full mr-4 mt-1">
                    <Scale className="h-5 w-5 text-blue-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">Case Outcome Prediction</h4>
                    <p className="text-gray-600">
                      Machine learning models trained on historical case data to predict outcomes with high accuracy
                    </p>
                  </div>
                </li>
                <li className="flex items-start">
                  <div className="bg-blue-100 p-2 rounded-full mr-4 mt-1">
                    <Gavel className="h-5 w-5 text-blue-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">Jurisdiction-Aware Analysis</h4>
                    <p className="text-gray-600">
                      Tailors advice based on specific jurisdictional requirements and precedents
                    </p>
                  </div>
                </li>
              </ul>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="bg-white p-8 rounded-xl shadow-xl"
            >
              <div className="bg-blue-50 p-6 rounded-lg mb-6">
                <div className="flex justify-between items-start mb-4">
                  <div className="flex items-center">
                    <div className="bg-blue-600 rounded-full p-2 mr-3">
                      <Bot className="h-6 w-6 text-white" />
                    </div>
                    <span className="font-medium text-gray-900">Justice AI</span>
                  </div>
                  <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded-full">Active</span>
                </div>
                <p className="text-gray-700 mb-4">
                  I've analyzed your landlord dispute case and found several potential violations of tenant rights under
                  California law:
                </p>
                <ul className="space-y-2 mb-4">
                  <li className="flex items-start">
                    <div className="text-blue-600 mr-2 mt-1">•</div>
                    <p className="text-gray-700">Failure to maintain habitable premises (Cal. Civil Code § 1941.1)</p>
                  </li>
                  <li className="flex items-start">
                    <div className="text-blue-600 mr-2 mt-1">•</div>
                    <p className="text-gray-700">Improper handling of security deposit (Cal. Civil Code § 1950.5)</p>
                  </li>
                  <li className="flex items-start">
                    <div className="text-blue-600 mr-2 mt-1">•</div>
                    <p className="text-gray-700">
                      Potential retaliation for repair requests (Cal. Civil Code § 1942.5)
                    </p>
                  </li>
                </ul>
                <div className="border-t border-gray-200 pt-4">
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-500">Case strength assessment</span>
                    <span className="text-sm font-medium text-blue-600">Moderate to Strong</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2.5 mt-2">
                    <div className="bg-blue-600 h-2.5 rounded-full w-[70%]"></div>
                  </div>
                </div>
              </div>
              <div className="flex justify-between">
                <div className="flex items-center text-sm text-gray-500">
                  <Lock className="h-4 w-4 mr-1" />
                  <span>HIPAA & GDPR Compliant</span>
                </div>
                <div className="flex items-center text-sm text-gray-500">
                  <Zap className="h-4 w-4 mr-1" />
                  <span>Real-time Analysis</span>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-blue-700 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-3xl font-bold text-white mb-6"
          >
            Ready to transform your legal experience?
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.6 }}
            viewport={{ once: true }}
            className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto"
          >
            Join thousands of individuals and legal professionals already using our platform
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.6 }}
            viewport={{ once: true }}
            className="flex flex-col sm:flex-row justify-center gap-4"
          >
            <motion.a
              href="/src/pages/signin?role=consumer"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="bg-white text-blue-700 px-8 py-3 rounded-md hover:bg-gray-100 transition-colors duration-200 font-semibold text-lg"
            >
              Get Started as Individual
            </motion.a>
            <motion.a
              href="/src/pages/signin?role=professional"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="bg-blue-600 text-white border border-blue-400 px-8 py-3 rounded-md hover:bg-blue-800 transition-colors duration-200 font-semibold text-lg"
            >
              Join as Legal Professional
            </motion.a>
          </motion.div>
        </div>
      </div>
    </Layout>
  )
}
