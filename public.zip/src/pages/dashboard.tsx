"use client"
import { useEffect } from "react"
import { useRouter } from "next/router"
import Head from "next/head"
import { useAuth } from "../contexts/AuthContext"
import ProtectedRoute from "../components/ProtectedRoute"

export default function Dashboard() {
  const { currentUser, userRole } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (currentUser) {
      if (userRole === "consumer") {
        router.push("/consumer-dashboard")
      } else if (userRole === "professional") {
        router.push("/professional-dashboard")
      }
    }
  }, [currentUser, userRole, router])

  return (
    <ProtectedRoute>
      <Head>
        <title>Dashboard | My Legal AI</title>
      </Head>
      <div className="flex items-center justify-center min-h-screen bg-gray-50">
        <div className="w-16 h-16 border-t-4 border-blue-500 border-solid rounded-full animate-spin"></div>
      </div>
    </ProtectedRoute>
  )
}
